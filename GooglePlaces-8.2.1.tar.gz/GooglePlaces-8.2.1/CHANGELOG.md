Please go to https://developers.google.com/places/ios-sdk/releases to view the
Places iOS release notes.
